/* MyPlugin - Custom Login JavaScript */

document.getElementById('rememberme').checked = true;
